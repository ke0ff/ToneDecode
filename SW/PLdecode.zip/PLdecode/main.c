/********************************************************************
 ************ COPYRIGHT (c) 2025 by ke0ff, Taylor, TX   *************
 *
 *  File name: main.c
 *
 *  Module:    Control
 *
 *  Summary:   This is CTCSS Tone Decoder for the ATTiny3217
 *
 *******************************************************************/

/********************************************************************
 * Created: 11/24/25
 * Author : joe.haas
 * Executes the tone decoder application
 *
 * V0.0 SW Revnotes	11/24/25
 *	Initial project creation.
 *
 * ==================================================================
 * PLdec, GPIO, and Timer0B
 *
 * Timer0B is for application timers and ADC Fsamp code (runs at 1.2 KHz rate)
 * ADC: input ADC into sample buffer in driver_isr.c (TCB0_INT_vect)
 * USART is for debug
 * NVMCTRL <not used>
 * GPIO:
 *			PA0 - n/u (UPDI)
 *			PA1 - TSEL0		; input, tone select vector[5:0]
 *			PA2 - TSEL1		; input
 *			PA3 - TSEL2		; input
 *			PA4 - TSEL3		; input
 *			PA5 - TSEL4		; input
 *			PA6 - TSEL5		; output
 *			PA7 - spare		; output
 *
 *			PB0 - ADC		; input, analog, ch11
 *			PB1 - spare		; input
 *			PB2 - TXD		; output - dbug UART output to host
 *			PB3 - RXD		; input - captures debug UART cmds from host
 *			PB4 - spare		; input
 *			PB5 - spare		; input
 *			PB6 - spare		; input
 *			PB7 - DETO		; output, tone detected = 1, else 0
 *
 *			PC0 - spare		; input
 *			PC1 - spare		; input
 *			PC2 - spare		; input
 *			PC3 - spare		; input
 *			PC4 - spare		; input
 *			PC5 - spare		; input
 *
 *
 *		UART is optional debug port
 *
 *	!!! NEED TO REMEMBER THE FUSES !!! Wasted a lot of time on this chasing fuse ghosts left over from Artemis effort.
 *
 *	Goertz algorithm processes the NBUFF contents to detect a specific tone:
 *	Basic functionality is to detect a specific tone identified by the TSEL vector.
 *		Option 1: Compare tone energy against a fixed threshold to detect tone present
 *		Option 2: Calculate energies for selected tone, and one other tone located above or below the selected tone
 *				  and use the "phantom" tone to detect noise.  If "phantom" tone energy is close to the desired tone,
 *				  inhibit detection.
 *
 *********************************************************************/

#include <atmel_start.h>
#include "usart_basic.h"
#include "main.h"
#include "driver_init.h"

//==================================================
// local Fn declarations


//==================================================
//#define DBUG

#define TSTF	4096	// 1KHz test tone
#define sleep()  __asm__ __volatile__ ("sleep" ::: "memory")
#define MS1			(1)
#define	KEY_SCAN	(MS1*10)		// 10ms scan rate
#define	MUT_DLY		(MS1*1000)		// 1 sec mute delay
#define	PTTMASK	0x20
#define UP_MASK	0x40
#define DN_MASK	0x20
#define ROW0	0x02				// ROW is active low.  When a key is pressed, a low from a COL output
#define ROW1	0x04				//	triggers capture when the corresponding ROW input is low.
#define ROW2	0x08
#define ROW3	0x10
#define COL0	0x02				// COL is active low with DIR port used to connect a col to the matrix
#define COL1	0x04
#define COL2	0x08
#define COL3	0x01

#define	VERSION	"\nPLdec v0.0,Copyright (c) 11/24/2025 ke0ff, A.R.R.\n"


//-----------------------------------------------------------------------------
// main() application loop
//-----------------------------------------------------------------------------
int main(void)
{
#ifdef DBUG
	char cbuf[10];						// usart cmd buff
	volatile uint8_t	c;				// table index, col
#endif

	// Initializes MCU, drivers and middleware
	atmel_start_init();										// init MCU
	sei();													// enable global interrupt flag
	initsamp();												// perform IPL init of DDS Fn
//	putsu(VERSION);											// display SW vers
//	pttedg = 0xff;											// force 1st edge
#ifdef DBUG
//	putsu("DBUG\n");						// dbug
#endif
	wait_T(20);
	PORTC.OUT = 0;											// COL (portc) pins = 0 when set to output
															// COL outs are active low with DIR port used to enable 1 column at a time
	// DTMF application code
	while (1) {
		sleep();											// WAI (or WFI, depending on you preferred flavor of assembly)

#ifdef DBUG
//					puthex((r<<4)|col);		// dbug
//					putsu("\n");			// dbug
#endif
#ifdef DBUG
/*		// USART (dbug)
		if(gotmsg(0)){							// capture tone set commands
			gets(cbuf);							// "rc" are ASCII numbers for each nybble.  Any other character turns off tone
			r = cbuf[0];						// "rc" sets index into frequency tables.  Valid digits are 1, 2, 4, and 8.  0 for row sets test tone
			c = cbuf[1];
			r -= '0';
			c -= '0';
			if(r>=0 && c>=0 && r<4 && c<4){
				set_tone(delf_row[r], 0);
				set_tone(delf_col[c], 1);
				set_tone_on(1);
				putsu("on\n");
			}else{
				set_tone_on(0);
				putsu("off\n");
			}
		} // */
#endif
	}
}


// EOF main.c